#include "hello.h"

int main()
{
invokehello1();
invokehello2();
invokehello3();
}
